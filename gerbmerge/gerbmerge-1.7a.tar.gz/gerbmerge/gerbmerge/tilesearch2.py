#!/usr/bin/env python
"""Tile search using random placement and evaluation. Works surprisingly well.
--------------------------------------------------------------------

This program is licensed under the GNU General Public License (GPL).
See http://www.fsf.org for details of the license.

Andrew Sterian
Padnos School of Engineering
Grand Valley State University
<steriana@claymore.engineer.gvsu.edu>
<http://claymore.engineer.gvsu.edu/~steriana>
"""

import sys
import time
import random

import config
import tiling
import tilesearch1

_CkpointTime = 0.0         # Next time to print stats
_Placements = 0L           # Number of placements attempted
_TBestCount = 0           # Number of improvments (i.e. how ofter
_TBestTiling = None        # Best tiling so far
_TBestScore  = float(sys.maxint) # Smallest area so far

def printTilingStats():
  global _CkpointTime
  _CkpointTime = time.time() + 1

  if _TBestTiling:
    area = _TBestTiling.area()
    utilization = _TBestTiling.usedArea() / area * 100.0
  else:
    area = 999999.0
    utilization = 0.0

  print "\r  %7ld placements / Smallest area: %.1fcm^2 (%.1f sq. in.) / Best utilization: %.1f%%" % \
        (_Placements, area*2.54*2.54, area, utilization),

  sys.stdout.flush()

def _tile_search2(Jobs, X, Y, endTime, cfg=config.Config):
  global _TBestCount, _CkpointTime, _Placements, _TBestTiling, _TBestScore

  r = random.Random()
  N = len(Jobs)

  # M is the number of jobs that will be placed randomly.
  # N-M is the number of jobs that will be searched exhaustively.
  M = N - config.RandomSearchExhaustiveJobs
  M = max(M,0)

  xspacing = cfg['xspacing']
  yspacing = cfg['yspacing']
  
  # Must escape with Ctrl-C
  while 1:
    T = tiling.Tiling(X,Y)
    joborder = r.sample(range(N), N)

    minInletSize = tiling.minDimension(Jobs)

    for ix in joborder[:M]:
      Xdim,Ydim,job,rjob = Jobs[ix]
      
      T.removeInlets(minInletSize)

      if r.choice([0,1]):
        addpoints = T.validAddPoints(Xdim+xspacing,Ydim+yspacing)
        if not addpoints:
          break

        pt = r.choice(addpoints)
        T.addJob(pt, Xdim+xspacing, Ydim+yspacing, job)
      else:
        addpoints = T.validAddPoints(Ydim+xspacing,Xdim+yspacing)
        if not addpoints:
          break

        pt = r.choice(addpoints)
        T.addJob(pt, Ydim+xspacing, Xdim+yspacing, rjob)
    else:
      # Do exhaustive search on remaining jobs
      if N-M:
        remainingJobs = []
        for ix in joborder[M:]:
          remainingJobs.append(Jobs[ix])

        tilesearch1.initialize(0)
        tilesearch1._tile_search1(remainingJobs, T, 1, endTime)
        T = tilesearch1.bestTiling()

      if T:
        score = T.area()

        if score < _TBestScore:
          _TBestTiling,_TBestScore = T,score
          _TBestCount += 1
          if config.SearchNthResult > 0 and config.SearchNthResult <= _TBestCount:
                return
          if config.SearchUtil > 0 and config.SearchUtil <= T.usedArea() / T.area() * 100.0:
                return

        elif score == _TBestScore:
          if T.corners() < _TBestTiling.corners():
            _TBestTiling,_TBestScore = T,score
            _TBestCount += 1
            if config.SearchNthResult > 0 and config.SearchNthResult <= _TBestCount:
                return
            if config.SearchUtil > 0 and config.SearchUtil <= T.usedArea() / T.area() * 100.0:
                return

    _Placements += 1
    if config.SearchTimeout > 0 and endTime < time.time():
        raise KeyboardInterrupt, "Search timed out"
    # If we've been at this for a few seconds, print some status information
    if time.time() > _CkpointTime:
      printTilingStats()

  # end while 1

def tile_search2(Jobs, X, Y):
  """Wrapper around _tile_search2 to handle keyboard interrupt, etc."""
  global _CkpointTime, _Placements, _TBestTiling, _TBestScore

  startTime = time.time()
  _CkpointTime = startTime + 1
  _Placements = 0L
  _TBestTiling = None
  _TBestScore = float(sys.maxint)

  print '='*70
  print "Starting random placement trials. You must press Ctrl-C to"
  print "stop the process and use the best placement so far."
  print "Estimated maximum possible utilization is %.1f%%." % (tiling.maxUtilization(Jobs)*100)

  try:
    _tile_search2(Jobs, X, Y, startTime+config.SearchTimeout)
    printTilingStats()
    print
  except KeyboardInterrupt as e:
    printTilingStats()
    sys.stdout.write("\nInterrupted")
    if str(e) != "":
        sys.stdout.write(" (" + str(e) + ")")
    sys.stdout.write(".\n")

  computeTime = time.time() - startTime
  print "Computed %ld placements in %d seconds / %.1f placements/second" % (_Placements, computeTime, _Placements/computeTime)
  print '='*70

  return _TBestTiling
